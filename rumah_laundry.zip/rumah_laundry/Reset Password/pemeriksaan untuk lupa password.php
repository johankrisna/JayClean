<?php
// Koneksi ke database
$host = "localhost";
$user = "username"; // Ganti dengan username database Anda
$pass = "password"; // Ganti dengan password database Anda
$db   = "nama_database"; // Ganti dengan nama database Anda


$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Koneksi ke database gagal: " . $conn->connect_error);
}

// Ambil email dari form
$email = $_POST['email'];

// Periksa apakah email ada di database
$sql = "SELECT * FROM users WHERE email = '$email'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Email ditemukan, lakukan proses reset password dan kirim email verifikasi
    $newPassword = generateRandomPassword();
    $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);

    // Update password baru ke database
    $updateSql = "UPDATE users SET password = '$hashedPassword' WHERE email = '$email'";
    $conn->query($updateSql);

//--------------------------------------------------------------------------batas yang harus disesuaikan database---------------------------------------------------------------------------------------

    // Kirim email verifikasi dengan password baru
    $subject = "Reset Password";
    $message = "Password baru Anda: $newPassword";
    mail($email, $subject, $message);

    echo "Password baru telah dikirim ke email Anda.";
} else {
    // Email tidak ditemukan
    echo "Maaf, email Anda salah.";
}

// Fungsi untuk menghasilkan password acak
function generateRandomPassword($length = 8) {
    $characters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    $password = '';
    for ($i = 0; $i < $length; $i++) {
        $password .= $characters[rand(0, strlen($characters) - 1)];
    }
    return $password;
}

$conn->close();
?>
